#!/bin/bash
echo "========================================"
echo "   舒尔特方格双人PK赛"
echo "========================================"
echo "正在启动本地服务器..."
echo "游戏将在浏览器中自动打开"
echo "按 Ctrl+C 关闭服务器"
echo "========================================"

# Find Python
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "错误：未找到 Python，请安装 Python 后重试"
    echo "Mac: brew install python3"
    echo "Linux: sudo apt install python3"
    exit 1
fi

# Open browser
open http://localhost:8765 2>/dev/null || \
xdg-open http://localhost:8765 2>/dev/null || \
echo "请手动打开 http://localhost:8765"

# Start server
$PYTHON -m http.server 8765
