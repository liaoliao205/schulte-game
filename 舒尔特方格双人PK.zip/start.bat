@echo off
chcp 65001 >nul
echo ========================================
echo   舒尔特方格双人PK赛
echo ========================================
echo 正在启动本地服务器...
echo 游戏将在浏览器中自动打开
echo 按 Ctrl+C 关闭服务器
echo ========================================

:: Find Python
where python >nul 2>&1 && set PYTHON=python && goto found
where python3 >nul 2>&1 && set PYTHON=python3 && goto found
echo 错误：未找到 Python，请安装 Python 后重试
echo 下载地址：https://www.python.org/downloads/
pause
exit /b 1

:found
%PYTHON% -m http.server 8765 >nul 2>&1 &
timeout /t 1 >nul
start http://localhost:8765
echo 游戏已启动！在浏览器中访问：http://localhost:8765
%PYTHON% -m http.server 8765
