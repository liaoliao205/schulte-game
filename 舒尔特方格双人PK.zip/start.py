#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Start a local HTTP server and open the game in browser."""

import os
import sys
import subprocess
import webbrowser
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 8765


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    print("=" * 40)
    print("   舒尔特方格双人PK赛")
    print("=" * 40)
    print("游戏地址：http://localhost:{}".format(PORT))
    print("按 Ctrl+C 关闭服务器")
    print("=" * 40)

    # Open browser
    url = "http://localhost:{}".format(PORT)
    time.sleep(0.5)
    webbrowser.open(url)

    # Start server
    server = HTTPServer(("", PORT), SimpleHTTPRequestHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务器已关闭")
        server.shutdown()


if __name__ == "__main__":
    main()
